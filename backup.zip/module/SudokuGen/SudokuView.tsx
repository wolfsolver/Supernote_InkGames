import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Pressable, ActivityIndicator, ScrollView } from 'react-native';
import { generateSudoku, SudokuPuzzle } from './SudokuEngine';
import { log } from '../../utils/ConsoleLog';
import { GAMES_CONFIG } from '../../config/defaultSettings';

interface SudokuViewProps {
    onBack: () => void;
}

const SudokuView = ({ onBack }: SudokuViewProps) => {
    const [puzzle, setPuzzle] = useState<SudokuPuzzle | null>(null);
    const [isExporting, setIsExporting] = useState(false);

    // Genera un puzzle all'avvio (default Easy)
    useEffect(() => {
        handleGenerate('easy');
    }, []);

    const handleGenerate = (diff: 'easy' | 'medium' | 'hard') => {
        log("Sudoku", `Generating new ${diff} puzzle`);
        const newPuzzle = generateSudoku(diff);
        setPuzzle(newPuzzle);
    };

    const handleExport = async () => {
        if (!puzzle) return;
        setIsExporting(true);

        try {
            // 1. Generiamo l'HTML completo di metadati
            const htmlContent = buildSudokuHTML(puzzle);

            // 2. Chiamata al tuo bridge nativo (placeholder)
            log("Sudoku", "Sending HTML to Native Renderer...");
            // const pngPath = await SudokuNative.generateImage(htmlContent);

            // 3. Inserimento nella nota
            // await PluginNoteAPI.insertImage(pngPath);

            log("Sudoku", "Export completed!");
            onBack(); // Chiude la preview e torna al menu
        } catch (e) {
            log("Sudoku", "Error during export: " + e);
        } finally {
            setIsExporting(false);
        }
    };

    const buildSudokuHTML = (puzzle: SudokuPuzzle): string => {
        const cellSize = 60;
        const borderWidth = 2;
        const gridWidth = cellSize * 9 + borderWidth * 2;
        const gridHeight = cellSize * 9 + borderWidth * 2;

        let html = `
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {
                    margin: 0;
                    padding: 0;
                    background-color: #ffffff;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    height: 100vh;
                    width: 100vw;
                }
                .grid-container {
                    display: grid;
                    grid-template-columns: repeat(9, ${cellSize}px);
                    grid-template-rows: repeat(9, ${cellSize}px);
                    border: ${borderWidth}px solid #000000;
                    background-color: #ffffff;
                }
                .cell {
                    width: ${cellSize}px;
                    height: ${cellSize}px;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    font-size: ${cellSize * 0.6}px;
                    font-weight: bold;
                    color: #000000;
                    box-sizing: border-box;
                }
                .thick-right {
                    border-right: ${borderWidth * 2}px solid #000000;
                }
                .thick-bottom {
                    border-bottom: ${borderWidth * 2}px solid #000000;
                }
                .thick-left {
                    border-left: ${borderWidth * 2}px solid #000000;
                }
                .thick-top {
                    border-top: ${borderWidth * 2}px solid #000000;
                }
            </style>
        </head>
        <body>
            <div class="grid-container">
    `;

        for (let i = 0; i < 81; i++) {
            const char = puzzle.puzzle[i];
            const row = Math.floor(i / 9);
            const col = i % 9;

            let classes = "cell";
            if ((col + 1) % 3 === 0 && col < 8) classes += " thick-right";
            if ((row + 1) % 3 === 0 && row < 8) classes += " thick-bottom";
            if (col === 0) classes += " thick-left";
            if (row === 0) classes += " thick-top";

            const displayChar = char === '.' ? '' : char;

            html += `<div class="${classes}">${displayChar}</div>`;
        }

        html += `
            </div>
        </body>
        </html>
    `;

        return html;
    };

    const renderGrid = () => {
        if (!puzzle) return null;

        const cells = puzzle.puzzle.split(''); // Splitta la stringa di 81 caratteri

        return (
            <View style={styles.gridBoard}>
                {Array.from({ length: 9 }).map((_, rowIndex) => (
                    <View key={`row-${rowIndex}`} style={styles.row}>
                        {cells.slice(rowIndex * 9, (rowIndex + 1) * 9).map((char, colIndex) => {
                            const isRightEdge = (colIndex + 1) % 3 === 0 && colIndex < 8;
                            const isBottomEdge = (rowIndex + 1) % 3 === 0 && rowIndex < 8;

                            return (
                                <View
                                    key={`cell-${rowIndex}-${colIndex}`}
                                    style={[
                                        styles.cell,
                                        isRightEdge && styles.thickRight,
                                        isBottomEdge && styles.thickBottom
                                    ]}
                                >
                                    <Text style={styles.cellText}>
                                        {char === '.' ? '' : char}
                                    </Text>
                                </View>
                            );
                        })}
                    </View>
                ))}
            </View>
        );
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={styles.title}>Sudoku Preview</Text>

            {puzzle ? (
                <>
                    <Text style={styles.subtitle}>Difficulty: {puzzle.difficulty}</Text>

                    {renderGrid()}

                    <View style={styles.controls}>
                        <Text style={styles.label}>Change Difficulty:</Text>
                        <View style={styles.buttonRow}>
                            <Pressable style={styles.miniBtn} onPress={() => handleGenerate('easy')}>
                                <Text style={styles.miniBtnText}>Easy</Text>
                            </Pressable>
                            <Pressable style={styles.miniBtn} onPress={() => handleGenerate('medium')}>
                                <Text style={styles.miniBtnText}>Med</Text>
                            </Pressable>
                            <Pressable style={styles.miniBtn} onPress={() => handleGenerate('hard')}>
                                <Text style={styles.miniBtnText}>Hard</Text>
                            </Pressable>
                        </View>

                        <Pressable
                            style={[styles.exportBtn, isExporting && styles.disabledBtn]}
                            onPress={handleExport}
                            disabled={isExporting}
                        >
                            {isExporting ? (
                                <ActivityIndicator color="#FFF" />
                            ) : (
                                <Text style={styles.exportBtnText}>INSERT INTO NOTE</Text>
                            )}
                        </Pressable>
                    </View>
                </>
            ) : (
                <ActivityIndicator size="large" color="#000" />
            )}

            <Pressable onPress={onBack} style={styles.backBtn}>
                <Text style={styles.backBtnText}>← Back to Menu</Text>
            </Pressable>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        alignItems: 'center',
        paddingVertical: 40,
        backgroundColor: '#FFF',
    },
    title: { fontSize: 28, fontWeight: '800', marginBottom: 5 },
    subtitle: { fontSize: 16, color: '#666', marginBottom: 20, textTransform: 'uppercase' },
    gridBoard: {
        borderWidth: 3,
        borderColor: '#000',
        backgroundColor: '#FFF',
    },
    row: { flexDirection: 'row' },
    cell: {
        width: 60,
        height: 60,
        borderWidth: 0.5,
        borderColor: '#CCC',
        justifyContent: 'center',
        alignItems: 'center',
    },
    cellText: { fontSize: 24, fontWeight: 'bold', color: '#000' },
    thickRight: { borderRightWidth: 3, borderRightColor: '#000' },
    thickBottom: { borderBottomWidth: 3, borderBottomColor: '#000' },
    controls: { marginTop: 30, alignItems: 'center', width: '100%' },
    label: { fontSize: 14, fontWeight: '600', marginBottom: 10 },
    buttonRow: { flexDirection: 'row', gap: 10, marginBottom: 30 },
    miniBtn: {
        paddingVertical: 10,
        paddingHorizontal: 20,
        borderWidth: 2,
        borderColor: '#000',
        borderRadius: 8,
    },
    miniBtnText: { fontWeight: 'bold' },
    exportBtn: {
        width: 300,
        height: 70,
        backgroundColor: '#000',
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 10,
    },
    exportBtnText: { color: '#FFF', fontWeight: 'bold', fontSize: 18 },
    disabledBtn: { backgroundColor: '#666' },
    backBtn: { marginTop: 40, padding: 10 },
    backBtnText: { textDecorationLine: 'underline', color: '#000' }
});

export default SudokuView;