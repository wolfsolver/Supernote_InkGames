// module/SudokuGen/SudokuEngine.ts
import sudoku from './sudoku'; // Ora funzionerà correttamente

export interface SudokuPuzzle {
    puzzle: string;
    //    solution: string;
    difficulty: string;
}

export const generateSudoku = (difficulty: 'easy' | 'medium' | 'hard'): SudokuPuzzle => {
    // sudoku.js usa 'easy', 'medium', 'hard' come chiavi interne
    const puzzleStr = sudoku.generate(difficulty);
    //    const solutionStr = sudoku.solve(puzzleStr);

    return {
        puzzle: puzzleStr,
        //        solution: solutionStr,
        difficulty: difficulty
    };
};